import 'package:flutter/material.dart';

void main() => runApp(const SharkGymApp());

class SharkGymApp extends StatelessWidget {
  const SharkGymApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Gym Shark',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0B0F14),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF63E36D),
          brightness: Brightness.dark,
        ),
        fontFamily: 'Roboto',
      ),
      home: const SplashGate(),
    );
  }
}

class SplashGate extends StatefulWidget {
  const SplashGate({super.key});

  @override
  State<SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<SplashGate> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1400), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const MainShell()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF05080D),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Image.asset('assets/shark_gym_logo.png', fit: BoxFit.contain),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  final pages = const [
    HomePage(),
    WorkoutPage(),
    DietPage(),
    ProgressPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        backgroundColor: const Color(0xFF11161D),
        indicatorColor: const Color(0xFF294B2D),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.fitness_center_outlined), selectedIcon: Icon(Icons.fitness_center), label: 'Workout'),
          NavigationDestination(icon: Icon(Icons.restaurant_outlined), selectedIcon: Icon(Icons.restaurant), label: 'Diet'),
          NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Progress'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  const AppCard({super.key, required this.child, this.padding = const EdgeInsets.all(18)});

  @override
  Widget build(BuildContext context) => Container(
    padding: padding,
    decoration: BoxDecoration(
      color: const Color(0xFF151B23),
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: Colors.white.withOpacity(.06)),
    ),
    child: child,
  );
}

class PrimaryButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  const PrimaryButton({super.key, required this.text, required this.onPressed});

  @override
  Widget build(BuildContext context) => SizedBox(
    width: double.infinity,
    height: 54,
    child: FilledButton(
      onPressed: onPressed,
      style: FilledButton.styleFrom(
        backgroundColor: const Color(0xFF63E36D),
        foregroundColor: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
    ),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 22, 20, 28),
      children: [
        Center(
          child: SizedBox(
            height: 92,
            child: Image.asset('assets/shark_gym_logo.png', fit: BoxFit.contain),
          ),
        ),
        const SizedBox(height: 10),
        const Text('Good Morning 👋', style: TextStyle(fontSize: 16, color: Colors.white70)),
        const SizedBox(height: 4),
        const Text('Gaurabh', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
        const SizedBox(height: 22),
        AppCard(
          child: Row(
            children: [
              const Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text("TODAY'S WORKOUT", style: TextStyle(color: Colors.white60, fontSize: 12, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text('Chest & Triceps', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                  SizedBox(height: 5),
                  Text('6 exercises • 45 min', style: TextStyle(color: Colors.white60)),
                  SizedBox(height: 16),
                  _MiniTag(text: 'Intermediate'),
                ]),
              ),
              Container(
                width: 82, height: 82,
                decoration: BoxDecoration(color: const Color(0xFF203425), borderRadius: BorderRadius.circular(20)),
                child: const Icon(Icons.fitness_center, size: 42, color: Color(0xFF63E36D)),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        const PrimaryButton(text: 'START WORKOUT', onPressed: _noop),
        const SizedBox(height: 22),
        const Text('Daily Progress', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        Row(children: const [
          Expanded(child: _StatCard(icon: Icons.local_fire_department, value: '320', label: 'kcal')),
          SizedBox(width: 10),
          Expanded(child: _StatCard(icon: Icons.water_drop, value: '4/8', label: 'glasses')),
          SizedBox(width: 10),
          Expanded(child: _StatCard(icon: Icons.directions_walk, value: '6.2K', label: 'steps')),
        ]),
        const SizedBox(height: 22),
        const Text('Your Goal', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        AppCard(
          child: Row(children: [
            SizedBox(
              width: 76, height: 76,
              child: Stack(alignment: Alignment.center, children: [
                CircularProgressIndicator(value: .68, strokeWidth: 8, color: const Color(0xFF63E36D), backgroundColor: Colors.white12),
                const Text('68%', style: TextStyle(fontWeight: FontWeight.bold)),
              ]),
            ),
            const SizedBox(width: 18),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Weekly target', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              SizedBox(height: 5),
              Text('Keep going! You are on track.', style: TextStyle(color: Colors.white60)),
            ])),
          ]),
        ),
      ],
    );
  }
}

class _MiniTag extends StatelessWidget {
  final String text;
  const _MiniTag({required this.text});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(20)),
    child: Text(text, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
  );
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String value, label;
  const _StatCard({required this.icon, required this.value, required this.label});
  @override
  Widget build(BuildContext context) => AppCard(
    padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 10),
    child: Column(children: [
      Icon(icon, color: const Color(0xFF63E36D), size: 22),
      const SizedBox(height: 8),
      Text(value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
      Text(label, style: const TextStyle(color: Colors.white54, fontSize: 11)),
    ]),
  );
}

class WorkoutPage extends StatelessWidget {
  const WorkoutPage({super.key});

  @override
  Widget build(BuildContext context) {
    final categories = ['All', 'Chest', 'Back', 'Legs', 'Shoulders', 'Arms', 'Abs'];
    final workouts = [
      ('Full Body Strength', '8 exercises • 50 min', Icons.accessibility_new),
      ('Chest & Triceps', '6 exercises • 45 min', Icons.fitness_center),
      ('Leg Day', '7 exercises • 48 min', Icons.directions_run),
      ('Quick Abs', '5 exercises • 15 min', Icons.sports_gymnastics),
    ];
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Workouts', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
        const SizedBox(height: 5),
        const Text('Train smarter. Get stronger.', style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 18),
        SizedBox(
          height: 42,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: categories.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (_, i) => Chip(
              label: Text(categories[i]),
              backgroundColor: i == 0 ? const Color(0xFF294B2D) : const Color(0xFF151B23),
              side: BorderSide.none,
            ),
          ),
        ),
        const SizedBox(height: 18),
        ...workouts.map((w) => Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: AppCard(child: ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Container(
              width: 58, height: 58,
              decoration: BoxDecoration(color: const Color(0xFF203425), borderRadius: BorderRadius.circular(16)),
              child: Icon(w.$3, color: const Color(0xFF63E36D)),
            ),
            title: Text(w.$1, style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(w.$2, style: const TextStyle(color: Colors.white54)),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => WorkoutDetailPage(title: w.$1))),
          )),
        )),
      ],
    );
  }
}

class WorkoutDetailPage extends StatelessWidget {
  final String title;
  const WorkoutDetailPage({super.key, required this.title});
  @override
  Widget build(BuildContext context) {
    final exercises = ['Push Ups', 'Dumbbell Press', 'Incline Press', 'Cable Fly', 'Triceps Pushdown', 'Bench Dips'];
    return Scaffold(
      appBar: AppBar(title: const Text('Workout Details')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(title, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          const Text('6 exercises • 45 min • Intermediate', style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 22),
          ...exercises.asMap().entries.map((e) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: AppCard(child: Row(children: [
              CircleAvatar(backgroundColor: const Color(0xFF294B2D), child: Text('${e.key + 1}')),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(e.value, style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 3),
                const Text('3 sets × 12 reps', style: TextStyle(color: Colors.white54, fontSize: 12)),
              ])),
              const Icon(Icons.play_circle_outline, color: Color(0xFF63E36D)),
            ])),
          )),
          const SizedBox(height: 10),
          PrimaryButton(text: 'START WORKOUT', onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const ActiveWorkoutPage()));
          }),
        ],
      ),
    );
  }
}

class ActiveWorkoutPage extends StatefulWidget {
  const ActiveWorkoutPage({super.key});
  @override
  State<ActiveWorkoutPage> createState() => _ActiveWorkoutPageState();
}
class _ActiveWorkoutPageState extends State<ActiveWorkoutPage> {
  int seconds = 45;
  bool running = false;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Active Workout')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(children: [
        const Spacer(),
        const Text('PUSH UPS', style: TextStyle(color: Colors.white60, letterSpacing: 2, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const Text('3 × 12', style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900)),
        const SizedBox(height: 28),
        Container(
          width: 210, height: 210,
          decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: const Color(0xFF63E36D), width: 10)),
          child: Center(child: Text('${seconds}s', style: const TextStyle(fontSize: 50, fontWeight: FontWeight.w800))),
        ),
        const SizedBox(height: 28),
        const Text('Rest Timer', style: TextStyle(color: Colors.white60)),
        const Spacer(),
        PrimaryButton(text: running ? 'PAUSE TIMER' : 'START TIMER', onPressed: () => setState(() => running = !running)),
        const SizedBox(height: 12),
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Finish Workout')),
      ]),
    ),
  );
}

class DietPage extends StatelessWidget {
  const DietPage({super.key});
  @override
  Widget build(BuildContext context) {
    final meals = [
      ('Breakfast', 'Oats + Banana + Eggs', '520 kcal', Icons.free_breakfast),
      ('Lunch', 'Rice + Dal + Paneer + Salad', '680 kcal', Icons.lunch_dining),
      ('Snack', 'Greek Yogurt + Fruit', '220 kcal', Icons.apple),
      ('Dinner', 'Roti + Chicken + Vegetables', '590 kcal', Icons.dinner_dining),
    ];
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Diet & Nutrition', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
        const SizedBox(height: 5),
        const Text('Simple Indian meals for your goal.', style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 18),
        AppCard(child: Row(children: const [
          Expanded(child: _Macro(value: '2,010', label: 'Calories')),
          Expanded(child: _Macro(value: '125g', label: 'Protein')),
          Expanded(child: _Macro(value: '220g', label: 'Carbs')),
        ])),
        const SizedBox(height: 20),
        ...meals.map((m) => Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: AppCard(child: ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(m.$4, color: const Color(0xFF63E36D), size: 30),
            title: Text(m.$1, style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(m.$2, style: const TextStyle(color: Colors.white60)),
            trailing: Text(m.$3, style: const TextStyle(fontWeight: FontWeight.bold)),
          )),
        )),
      ],
    );
  }
}

class _Macro extends StatelessWidget {
  final String value, label;
  const _Macro({required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Column(children: [
    Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
    const SizedBox(height: 4),
    Text(label, style: const TextStyle(color: Colors.white54, fontSize: 11)),
  ]);
}

class ProgressPage extends StatelessWidget {
  const ProgressPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('Progress', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
      const SizedBox(height: 5),
      const Text('Your consistency is your superpower.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 20),
      AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Weight', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
        const SizedBox(height: 4),
        const Text('72.0 kg', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
        const SizedBox(height: 18),
        SizedBox(height: 150, child: CustomPaint(painter: _ChartPainter())),
      ])),
      const SizedBox(height: 14),
      Row(children: const [
        Expanded(child: _ProgressStat(value: '18', label: 'Workouts')),
        SizedBox(width: 10),
        Expanded(child: _ProgressStat(value: '6.4 kg', label: 'Lost')),
        SizedBox(width: 10),
        Expanded(child: _ProgressStat(value: '12', label: 'Day streak')),
      ]),
    ],
  );
}

class _ProgressStat extends StatelessWidget {
  final String value, label;
  const _ProgressStat({required this.value, required this.label});
  @override
  Widget build(BuildContext context) => AppCard(child: Column(children: [
    Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
    const SizedBox(height: 4),
    Text(label, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, fontSize: 11)),
  ]));
}

class _ChartPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = const Color(0xFF63E36D)..strokeWidth = 4..style = PaintingStyle.stroke;
    final path = Path()
      ..moveTo(0, size.height * .75)
      ..lineTo(size.width * .18, size.height * .60)
      ..lineTo(size.width * .35, size.height * .68)
      ..lineTo(size.width * .52, size.height * .42)
      ..lineTo(size.width * .70, size.height * .50)
      ..lineTo(size.width * .86, size.height * .25)
      ..lineTo(size.width, size.height * .32);
    canvas.drawPath(path, p);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('Profile', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
      const SizedBox(height: 20),
      AppCard(child: Row(children: [
        const CircleAvatar(radius: 34, backgroundColor: Color(0xFF294B2D), child: Icon(Icons.person, size: 36)),
        const SizedBox(width: 16),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Gaurabh', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          SizedBox(height: 4),
          Text('Muscle Gain • 72 kg', style: TextStyle(color: Colors.white60)),
        ])),
        IconButton(onPressed: _noop, icon: const Icon(Icons.edit_outlined)),
      ])),
      const SizedBox(height: 14),
      ...[
        ('Personal Details', Icons.person_outline),
        ('Goals & Targets', Icons.flag_outlined),
        ('Notifications', Icons.notifications_none),
        ('App Settings', Icons.settings_outlined),
      ].map((x) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: AppCard(child: ListTile(
          contentPadding: EdgeInsets.zero,
          leading: Icon(x.$2, color: const Color(0xFF63E36D)),
          title: Text(x.$1, style: const TextStyle(fontWeight: FontWeight.w700)),
          trailing: const Icon(Icons.chevron_right),
        )),
      )),
    ],
  );
}

void _noop() {}
