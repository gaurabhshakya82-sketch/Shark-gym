# Shark Gym

**Shark Gym** fitness app prototype with the new Shark Gym logo integrated.

### Logo integration
- `assets/shark_gym_logo.png` is the new Shark Gym logo.
- The logo is shown on the splash screen and Home screen branding.
- The project uses the app name **Shark Gym**.

### Run
1. Install Flutter and Android Studio.
2. Open this project in Android Studio.
3. Run `flutter pub get`.
4. Run `flutter run`.

### Build release APK
`flutter build apk --release`

### Note
This V1 is a UI prototype. Firebase authentication, persistent data, real exercise media,
notifications, health integrations and subscriptions are planned for the next phase.
